package com.mycompany.designpatterns_command;
public interface Comando {
    void executar();
}
